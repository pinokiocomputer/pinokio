## What's New
- [x] Add error handling and elevated privileges attempt for the quarantine and sign drops - #9
- [x] Update AF swift package and functions
